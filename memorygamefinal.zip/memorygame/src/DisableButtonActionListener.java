import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Objects;
import java.util.concurrent.TimeUnit;


public class DisableButtonActionListener implements ActionListener {
    static String text="";
    static JButton oldSource;
    static int counter;
    static int lives=!String.valueOf(MainFrame.Lives.getText().charAt(2)).equals("∞")?Integer.parseInt(String.valueOf(MainFrame.Lives.getText().charAt(2))):3;
    static int multiplier;
    static int score;
    static int high;

    public void playSound() throws LineUnavailableException, IOException, UnsupportedAudioFileException {
        String soundName = "src/assets/boop.wav";
        AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(soundName).getAbsoluteFile());
        Clip clip = AudioSystem.getClip();
        clip.open(audioInputStream);
        clip.start();
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            playSound();
        } catch (LineUnavailableException | IOException | UnsupportedAudioFileException ex) {
            throw new RuntimeException(ex);
        }
        JButton source = (JButton) e.getSource();
        source.setIcon(FindIcon(e));
        source.setDisabledIcon(FindIcon(e));
        source.setEnabled(false);
        source.setBackground(new Color(141, 2, 130));
        if (Objects.equals(text, "")) {
            text=source.getName();
            oldSource=source;
        }
        else {
            source.setIcon(FindIcon(e));
            if (text.equals(source.getName())) {
                oldSource.setBackground(Color.green);
                source.setBackground(Color.green);
                oldSource.setEnabled(false);
                source.setEnabled(false);
                text="";
                counter++;
                multiplier++;
                score+=score!=0?10* multiplier :10;
                MainFrame.Score.setText("| Score : "+score);
            }
            else {
                ActionListener listener = event -> {
                    try {
                        TimeUnit.SECONDS.sleep(1);
                    } catch (InterruptedException ex) {
                        throw new RuntimeException(ex);
                    }
                    text="";
                    oldSource.setBackground(new Color(141, 2, 179));
                    source.setBackground(new Color(141, 2, 179));
                    oldSource.setIcon(null);
                    source.setIcon(null);
                    oldSource.setEnabled(true);
                    source.setEnabled(true);
                    score=score!=0?score-1:0;
                    MainFrame.Score.setText("| Score : "+score);
                    if (!String.valueOf(MainFrame.Lives.getText().charAt(2)).equals("∞")) {
                        MainFrame.Lives.setText("| " + (Integer.parseInt(String.valueOf(MainFrame.Lives.getText().charAt(2))) - 1) + "♥");
                        --lives;
                    }
                    multiplier=0;
                    CheckLives();
                };
                Timer timer = new Timer(0, listener);
                timer.setRepeats(false);
                timer.start();
            }
        }
        CheckLives();
    }

    public void CheckLives() {
        if (lives==0||counter==10) {
            MainFrame.getMainFrame().dispose();
            new MainMenu("pts : "+score,"PLAY");
            counter=0;
            high=Math.max(score, high);
            score=0;
            MainFrame.Score.setText("| Score : "+score);
            MainFrame.HighScore.setText("| HighScore : "+high);
        }
    }

    public ImageIcon FindIcon(ActionEvent e) {
        JButton source = (JButton) e.getSource();
        for (int i=0;i<MainFrame.sortedIcons.size();i++) {
            if (source.getName().equals(MainFrame.sortedIcons.elementAt(i).getDescription())) {
                return MainFrame.sortedIcons.elementAt(i);
            }
        }
        return null;
    }
}