import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

public class MainFrame {
    private static JFrame frame;
    public static JLabel Lives = new JLabel("| "+MainMenu.GetChoice()){{
        setFont(new Font("Arial", Font.BOLD, 18));
        setForeground(Color.white);
    }};
    public static JLabel Score = new JLabel("| Score : 0"){{
        setFont(new Font("Arial", Font.PLAIN, 18));
        setForeground(Color.white);
    }};
    public static JLabel HighScore = new JLabel("| HighScore : 0"){{
        setFont(new Font("Arial", Font.PLAIN, 18));
        setForeground(Color.white);
    }};
    public static Vector<ImageIcon> sortedIcons = new Vector<>();
    MainFrame() throws UnsupportedAudioFileException, LineUnavailableException, IOException {
        final Random r = new Random();
        JPanel mainPanel = new JPanel();
        frame = new JFrame();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.PAGE_AXIS));
        JPanel panel1 = new JPanel(new FlowLayout());
        JPanel panel2 = new JPanel(new GridLayout(4, 5, 5, 5));
        JPanel panel3 = new JPanel(new FlowLayout());

        JButton[] buttons = new JButton[20];

        JLabel timerLabel = new JLabel("00:00:00"){{
            setFont(new Font("Arial", Font.PLAIN, 18));
            setForeground(Color.white);
        }};

        final int[] elapsedTime = {0};

        final int[] seconds = {0};

        final int[] minutes = {0};

        final int[] hours = {0};

        final String[] seconds_string = {String.format("%02d", seconds[0])};

        final String[] minutes_string = {String.format("%02d", minutes[0])};

        final String[] hours_string = {String.format("%02d", hours[0])};

        javax.swing.Timer SimpleTimer = new javax.swing.Timer(1000, e -> {
            elapsedTime[0] = elapsedTime[0] +1000;

            hours[0] = (elapsedTime[0] /3600000);

            minutes[0] = (elapsedTime[0] /60000) % 60;

            seconds[0] = (elapsedTime[0] /1000) % 60;

            seconds_string[0] = String.format("%02d", seconds[0]);

            minutes_string[0] = String.format("%02d", minutes[0]);

            hours_string[0] = String.format("%02d", hours[0]);

            timerLabel.setText(hours_string[0] +":"+ minutes_string[0] +":"+ seconds_string[0]);

        });
        Vector<ImageIcon> icons = new Vector<>();
        addToVector(icons);
        for (int i = 0; i < buttons.length; i++) {
            int index = r.nextInt(icons.size());
            buttons[i] = new JButton();
            buttons[i].setIcon(icons.elementAt(index));
            buttons[i].setDisabledIcon(icons.elementAt(index));
            buttons[i].setEnabled(false);
            buttons[i].setSize(128, 128);
            buttons[i].setBackground(new Color(141, 2, 179));
            buttons[i].setFocusPainted(false);
            buttons[i].setName(String.valueOf(buttons[i].getIcon()));
            sortedIcons.add(icons.elementAt(index));
            icons.remove(index);
            panel2.add(buttons[i]);
            buttons[i].addActionListener(new DisableButtonActionListener());
        }
        SimpleTimer.start();
        Timer timer = new Timer();
        TimerTask task = new TimerTask(){
            int counter = 10;
            @Override
            public void run() {
                if(counter>0) {
                    counter--;
                    for (JButton i : buttons) {
                        if (counter % 2 == 0) {
                            i.setIcon(FindIcon(i));
                        } else {
                            i.setIcon(null);
                        }

                    }
                }
                else {
                    for (JButton i : buttons) {
                        i.setIcon(null);
                        i.setEnabled(true);
                        i.setBackground(new Color(141, 2, 179));
                    }
                    timer.cancel();
                }

            }
        };
        timer.scheduleAtFixedRate(task,0,500);

        JLabel title = new JLabel("MEMORY GAME"){{
            setFont(new Font("Arial", Font.BOLD, 28));
            setForeground(Color.white);
        }};
        JButton Close = new JButton(){{
            setFont(new Font("Arial", Font.PLAIN, 18));
            setBackground(Color.red);
            setText("Close");
            setFocusPainted(false);
        }};
        panel1.add(title);
        panel1.add(Box.createRigidArea(new Dimension(39, 0)));
        panel1.add(Close);
        panel1.setMaximumSize(new Dimension(360, 40));
        panel1.setBackground(new Color(0f, 0f, 0f, 0.0f));
        panel3.add(timerLabel);
        panel3.add(Score);
        panel3.add(HighScore);
        panel3.add(Lives);
        panel3.setMaximumSize(new Dimension(360, 40));
        panel3.setBackground(new Color(0f, 0f, 0f, 1f));
        panel2.setBackground(new Color(0f, 0f, 0f, 0.0f));
        mainPanel.add(panel1);
        mainPanel.add(panel3);
        mainPanel.add(panel2);
        Border padding = BorderFactory.createEmptyBorder(10, 10, 10, 10);
        mainPanel.setBorder(padding);
        mainPanel.setBackground(new Color(0f, 0f, 0f, 0.9f));
        frame.setContentPane(mainPanel);
        frame.setUndecorated(true);
        frame.setSize(380, 420);
        frame.setLocationRelativeTo(null);
        frame.setBackground(new Color(0f, 0f, 0f, 0.9f));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        Close.addActionListener(e -> frame.dispose());
    }
    public ImageIcon createImageIcon(String path,
                                     String description) {
        java.net.URL imgURL = getClass().getResource(path);
        if (imgURL != null) {
            return new ImageIcon(imgURL, description);
        } else {
            System.err.println("Couldn't find file: " + path);
            return null;
        }
    }
    public void addToVector(Vector<ImageIcon> icons) {
        sortedIcons.clear();
        StringBuilder s = new StringBuilder("ABCDEFGHIJABCDEFGHIJ");
        for (int i = 0; i < 20; i++) {
            icons.add(createImageIcon("assets/"+MainMenu.GetTheme()+"/"+s.charAt(i)+".PNG",String.valueOf(s.charAt(i))));
        }
    }

    public static JFrame getMainFrame() {
        return frame;
    }

    public ImageIcon FindIcon(JButton source) {
        for (int i=0;i<MainFrame.sortedIcons.size();i++) {
            if (source.getName().equals(MainFrame.sortedIcons.elementAt(i).getDescription())) {
                return MainFrame.sortedIcons.elementAt(i);
            }
        }
        return null;
    }


}
