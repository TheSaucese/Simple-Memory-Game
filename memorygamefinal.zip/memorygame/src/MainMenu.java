import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.Objects;
import java.util.Vector;

public class MainMenu {
    static JComboBox<Object> DiffBox = new JComboBox<>(new Vector<>() {{
        add("∞♥");
        add("3♥");
        add("1♥");
    }}){{
        setPrototypeDisplayValue("WWW");
        setFont(new Font("Arial", Font.PLAIN, 18));
        setSize(170,32);
        setMinimumSize(new Dimension(120,32));
        setMaximumSize(new Dimension(120,32));
    }};
    static JComboBox<Object> ThemeBox = new JComboBox<>(new Vector<>() {{
        add("Fruits");
        add("Chess");
    }}){{
        setPrototypeDisplayValue("WWW");
        setFont(new Font("Arial", Font.PLAIN, 18));
        setSize(170,32);
        setMinimumSize(new Dimension(120,32));
        setMaximumSize(new Dimension(120,32));
    }};
    MainMenu(String title,String playText) {
        JPanel menu = new JPanel();
        menu.setLayout(null);
        Insets insets = menu.getInsets();
        JLabel welcome = new JLabel(title, SwingConstants.CENTER) {{
            setFont(new Font("Arial", Font.BOLD, 48));
            setSize(340,32);
            setMinimumSize(new Dimension(340,96));
            setMaximumSize(new Dimension(340,96));
        }};
        JButton play = new JButton(playText) {{
            setFont(new Font("Arial", Font.PLAIN, 18));
            setSize(170,32);
            setMinimumSize(new Dimension(170,32));
            setMaximumSize(new Dimension(170,32));
        }};
        ((JLabel)DiffBox.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        ((JLabel)ThemeBox.getRenderer()).setHorizontalAlignment(SwingConstants.CENTER);
        JButton close = new JButton(){{
            setSize(108,32);
            setMinimumSize(new Dimension(108,32));
            setMaximumSize(new Dimension(108,32));
        }};
        close.setFont(new Font("Arial", Font.PLAIN, 18));
        close.setBackground(Color.red);
        close.setText("Close");
        close.setFocusPainted(false);
        menu.add(close);
        menu.add(welcome);
        menu.add(DiffBox);
        menu.add(ThemeBox);
        menu.add(play);
        close.setBounds(350-close.getPreferredSize().width,insets.top+10,close.getPreferredSize().width,close.getPreferredSize().height);
        welcome.setBounds(70 + insets.left, 50 + insets.top,welcome.getPreferredSize().width, welcome.getPreferredSize().height);
        DiffBox.setBounds(120 + insets.left, 160 + insets.top, DiffBox.getPreferredSize().width + 50, DiffBox.getPreferredSize().height + 20);
        ThemeBox.setBounds(120 + insets.left, 220 + insets.top, ThemeBox.getPreferredSize().width + 50, ThemeBox.getPreferredSize().height + 20);
        play.setBounds(120 + insets.left, 280 + insets.top, play.getPreferredSize().width + 50, play.getPreferredSize().height + 20);
        JFrame frame = new JFrame();
        menu.setBackground(new Color(0f, 0f, 0f, 0.9f));
        frame.setContentPane(menu);
        frame.setUndecorated(true);
        frame.setSize(360, 360);
        frame.setLocationRelativeTo(null);
        frame.setBackground(new Color(0f, 0f, 0f, 0.9f));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        close.addActionListener(e -> frame.dispose());
        play.addActionListener(e -> {
            try {
                new MainFrame();
                MainFrame.Lives.setText("| "+GetChoice());
                DisableButtonActionListener.lives=!String.valueOf(MainFrame.Lives.getText().charAt(2)).equals("∞")?Integer.parseInt(String.valueOf(MainFrame.Lives.getText().charAt(2))):3;
            } catch (UnsupportedAudioFileException | LineUnavailableException | IOException ex) {
                throw new RuntimeException(ex);
            }
            frame.dispose();

        });
    }
    static String GetChoice() {
        return Objects.requireNonNull(DiffBox.getSelectedItem()).toString();
    }
    static String GetTheme() {
        return Objects.requireNonNull(ThemeBox.getSelectedItem()).toString();
    }
}
